﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Collisions : MonoBehaviour {
	Score_Script scoreScript;
	// Use this for initialization
	void Start () {
		GameObject scoreObject = GameObject.FindWithTag ("GameController");
		if (scoreObject != null) {
			scoreScript = scoreObject.GetComponent<Score_Script> ();
		} else
			scoreScript = null;
	}
	void OnCollisionEnter2D(Collision2D coll)
	{
		Destroy (coll.gameObject);
		scoreScript.AddScore (1);
	}
	// Update is called once per frame
	void Update () {
		
	}
}
