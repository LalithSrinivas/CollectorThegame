﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameBrain : MonoBehaviour {
	// Use this for initialization
	void Start () {
		GameObject rand = Resources.Load ("Waste_object") as GameObject;
		for (int i = 0; i < 10; i++) {
			GameObject Waste_object = Instantiate (rand) as GameObject;
			Waste_object.transform.position = new Vector2 (8, 17 + i * 20);
		}
	}
	
	// Update is called once per frame
	void FixedUpdate () {
		
	}
}
